/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main_master.c
  * @brief          : MASTER
  *                  - Lee potenciómetro (APPS) por ADC1_IN1 (PA0)
  *                  - Habla con el inversor DTI por CAN (Relative Current)
  *                  - Recibe estado del SLAVE (ID 0x600)
  *                  - Solo acelera si el SLAVE da OK
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "fdcan.h"
#include "gpio.h"

#include <string.h>

/* Private defines -----------------------------------------------------------*/
/* --- Control de corriente relativa --- */
#define REL_CURRENT_MIN          0           // 0%
#define REL_CURRENT_MAX          (100 * 10)  // 100.0% -> 1000 (escala 10)

/* --- Límites de seguridad --- */
#define LIMIT_MAX_AC_CURRENT     (15 * 10)   // 15 A -> 150
#define LIMIT_MAX_BRAKE_CURRENT  (0  * 10)   // 0 A  -> 0

/* --- Node ID del inversor (el que usabas antes) --- */
#define NODE_ID                  0x1B

/* --- Packet IDs (Manual CAN DTI) --- */
#define PACKET_ID_SET_REL_CURRENT  0x05
#define PACKET_ID_SET_MAX_AC       0x08
#define PACKET_ID_SET_MAX_BRAKE    0x09
#define PACKET_ID_DRIVE_ENABLE     0x0C

/* --- ID del mensaje que envía el SLAVE --- */
#define SLAVE_STATUS_ID          0x600U

/* Private typedef -----------------------------------------------------------*/
/* None */

/* Private macro -------------------------------------------------------------*/
#define MIN(a,b) (( (a) < (b) ) ? (a) : (b))

/* External handles ----------------------------------------------------------*/
extern ADC_HandleTypeDef   hadc1;
extern FDCAN_HandleTypeDef hfdcan1;

/* Private variables ---------------------------------------------------------*/
FDCAN_TxHeaderTypeDef TxHeader;
FDCAN_RxHeaderTypeDef RxHeader;
uint8_t TxData[8];
uint8_t RxData[8];

uint16_t adc_value           = 0;
uint16_t target_rel_current  = 0;

/* Estado del SLAVE */
volatile uint8_t  slave_ok           = 0;
volatile uint32_t last_slave_msg_ms  = 0;

/* Function prototypes -------------------------------------------------------*/
void SystemClock_Config(void);
static void Configure_FDCAN_Filters(void);
static void Send_CAN_Message(uint32_t id, uint8_t *data, uint8_t len);
static long map_long(long x, long in_min, long in_max, long out_min, long out_max);

/* USER CODE BEGIN 0 */

static long map_long(long x, long in_min, long in_max, long out_min, long out_max)
{
  if (in_max == in_min) return out_min;
  long num = (x - in_min) * (out_max - out_min);
  long den = (in_max - in_min);
  return out_min + num / den;
}

static void Send_CAN_Message(uint32_t id, uint8_t *data, uint8_t len)
{
  /* Siempre usamos 8 bytes, pero dejamos 'len' por si quieres variar */
  (void)len;

  TxHeader.Identifier = id;
  TxHeader.DataLength = FDCAN_DLC_BYTES_8;

  /* Esperar a que haya hueco en la FIFO de TX */
  while (HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &TxHeader, data) != HAL_OK)
  {
    /* Si está llena, podemos simplemente esperar un poco */
    HAL_Delay(1);
  }
}

static void Configure_FDCAN_Filters(void)
{
  FDCAN_FilterTypeDef sFilterConfig;

  /* Aceptar todos los IDs EXTENDIDOS en RX FIFO0 (incluyendo 0x600 e IDs del inversor si los quieres leer) */
  sFilterConfig.IdType       = FDCAN_EXTENDED_ID;
  sFilterConfig.FilterIndex  = 0;
  sFilterConfig.FilterType   = FDCAN_FILTER_MASK;
  sFilterConfig.FilterConfig = FDCAN_FILTER_TO_RXFIFO0;
  sFilterConfig.FilterID1    = 0x00000000U;  // ID base
  sFilterConfig.FilterID2    = 0x00000000U;  // máscara 0 => don't care

  if (HAL_FDCAN_ConfigFilter(&hfdcan1, &sFilterConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /* Filtro global: rechazamos estándar, aceptamos extendido en FIFO0 */
  if (HAL_FDCAN_ConfigGlobalFilter(
        &hfdcan1,
        FDCAN_REJECT,             // Std IDs: reject
        FDCAN_ACCEPT_IN_RX_FIFO0, // Ext IDs: accept in FIFO0
        FDCAN_FILTER_REMOTE,
        FDCAN_FILTER_REMOTE) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* Reset of all peripherals, init Flash & Systick */
  HAL_Init();

  /* Configure the system clock */
  SystemClock_Config();

  /* Init peripherals */
  MX_GPIO_Init();
  MX_FDCAN1_Init();
  MX_ADC1_Init();

  /* Configuración de filtros CAN (para recibir del SLAVE) */
  Configure_FDCAN_Filters();

  /* Arrancar FDCAN */
  if (HAL_FDCAN_Start(&hfdcan1) != HAL_OK)
  {
    Error_Handler();
  }

  /* Calibrar ADC */
  if (HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED) != HAL_OK)
  {
    Error_Handler();
  }

  /* Configuración base del TxHeader (común a todos los envíos) */
  TxHeader.IdType              = FDCAN_EXTENDED_ID;
  TxHeader.TxFrameType         = FDCAN_DATA_FRAME;
  TxHeader.DataLength          = FDCAN_DLC_BYTES_8;
  TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
  TxHeader.BitRateSwitch       = FDCAN_BRS_OFF;
  TxHeader.FDFormat            = FDCAN_CLASSIC_CAN;
  TxHeader.TxEventFifoControl  = FDCAN_NO_TX_EVENTS;
  TxHeader.MessageMarker       = 0;

  /* --- Enviar límites de seguridad UNA VEZ al arrancar --- */

  /* 1) Máx. AC Current = 15 A (150) */
  memset(TxData, 0, sizeof(TxData));
  TxData[0] = (uint8_t)((LIMIT_MAX_AC_CURRENT >> 8) & 0xFF);
  TxData[1] = (uint8_t)( LIMIT_MAX_AC_CURRENT       & 0xFF);
  uint32_t limit_ac_id = (PACKET_ID_SET_MAX_AC << 8) | NODE_ID;
  Send_CAN_Message(limit_ac_id, TxData, 8);
  HAL_Delay(10);

  /* 2) Máx. Brake Current = 0 A */
  memset(TxData, 0, sizeof(TxData));
  TxData[0] = (uint8_t)((LIMIT_MAX_BRAKE_CURRENT >> 8) & 0xFF);
  TxData[1] = (uint8_t)( LIMIT_MAX_BRAKE_CURRENT       & 0xFF);
  uint32_t limit_brake_id = (PACKET_ID_SET_MAX_BRAKE << 8) | NODE_ID;
  Send_CAN_Message(limit_brake_id, TxData, 8);
  HAL_Delay(10);

  /* Bucle principal --------------------------------------------------------*/
  while (1)
  {
    uint32_t now = HAL_GetTick();

    /* 1) Leer mensajes CAN (del SLAVE) */
    while (HAL_FDCAN_GetRxFifoFillLevel(&hfdcan1, FDCAN_RX_FIFO0) > 0U)
    {
      if (HAL_FDCAN_GetRxMessage(&hfdcan1, FDCAN_RX_FIFO0, &RxHeader, RxData) == HAL_OK)
      {
        if (RxHeader.Identifier == SLAVE_STATUS_ID)
        {
          /* Data[0] = 1 -> Botón OK (pulsado), 0 -> no OK */
          slave_ok          = (RxData[0] == 1U) ? 1U : 0U;
          last_slave_msg_ms = now;
        }
      }
    }

    /* 2) Leer potenciómetro (APPS) */
    HAL_ADC_Start(&hadc1);
    if (HAL_ADC_PollForConversion(&hadc1, 100) == HAL_OK)
    {
      adc_value = (uint16_t)HAL_ADC_GetValue(&hadc1);
    }

    /* 3) Mapear a corriente relativa (0–1000) */
    target_rel_current = (uint16_t)map_long((long)adc_value, 0L, 4095L,
                                            (long)REL_CURRENT_MIN, (long)REL_CURRENT_MAX);

    /* 4) Comprobar si el SLAVE está OK y reciente */
    uint8_t allowed = 0;
    if (slave_ok && ((now - last_slave_msg_ms) < 200U))
    {
      allowed = 1;
    }

    /* 5) Enviar DRIVE_ENABLE + SET_REL_CURRENT al inversor */

    /* DRIVE_ENABLE */
    memset(TxData, 0, sizeof(TxData));
    TxData[0] = allowed ? 0x01 : 0x00;   // 1 = habilitado, 0 = deshabilitado
    uint32_t drive_enable_id = (PACKET_ID_DRIVE_ENABLE << 8) | NODE_ID;
    Send_CAN_Message(drive_enable_id, TxData, 8);

    /* Relative Current */
    memset(TxData, 0, sizeof(TxData));

    uint16_t command_rel = allowed ? target_rel_current : 0U;
    /* Byte0-1: Relative Current (MSB, LSB) según tu escala */
    TxData[0] = (uint8_t)((command_rel >> 8) & 0xFF);
    TxData[1] = (uint8_t)( command_rel       & 0xFF);

    uint32_t rel_current_id = (PACKET_ID_SET_REL_CURRENT << 8) | NODE_ID;
    Send_CAN_Message(rel_current_id, TxData, 8);

    /* 6) (Opcional) Indicar en LED PA5 si estamos permitiendo acelerar */
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, allowed ? GPIO_PIN_SET : GPIO_PIN_RESET);

    HAL_Delay(50); // 20 Hz de actualización es suficiente
  }
}

/* SystemClock_Config: igual que en tus otros main_* ------------------------*/
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource       = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM            = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN            = 85;
  RCC_OscInitStruct.PLL.PLLP            = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ            = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR            = RCC_PLLR_DIV2;

  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK  | RCC_CLOCKTYPE_SYSCLK
                                   | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
    /* LED parpadeando rápido para indicar error */
    HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
    HAL_Delay(100);
  }
}
